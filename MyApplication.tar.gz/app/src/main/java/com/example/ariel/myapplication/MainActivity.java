package com.example.ariel.myapplication;

import android.os.NetworkOnMainThreadException;
import android.os.StrictMode;
import android.printservice.PrintService;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.TextView;

import com.lib.cd.ClienteCobroDigital;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.LinkedHashMap;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String sid = "MeAOO0d8tpk87Ud3AG0mZO7WCIP76GuKfU48UMVCuLO66aQGa0Iw3R6cDVs";
        String mercalpha = "CI366779";

        String desde = "20160607";
        String hasta = "20160715";
        LinkedHashMap filtros = new LinkedHashMap();
        String respueta="";
        try {
          ClienteCobroDigital cobro_digital = new ClienteCobroDigital(mercalpha, sid);
         if (!cobro_digital.consultar_transacciones(desde, hasta, filtros)) {
            respueta="si";

         } else {
             respueta="NO";
        }
    } catch (NetworkOnMainThreadException ex){
            System.out.println("hola");
            respueta="NO";
            ex.printStackTrace();
        }
        catch (Exception ex) {
        ex.printStackTrace();
        respueta="si";

        System.out.println("error");
        }
        //String url_parameters = http_build_query(array:_a_enviar);

        TextView tv = (TextView) findViewById(R.id.TEXTO);
        tv.setText(respueta);

    }

}
